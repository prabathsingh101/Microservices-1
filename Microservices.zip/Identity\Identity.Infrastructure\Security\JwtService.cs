using Identity.Domain.Users;
using Identity.Application.DTOs;
using Identity.Application.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Identity.Domain;

namespace Identity.Infrastructure.Security;

public class JwtService : IJwtService
{
    private readonly IConfiguration _config;

    public JwtService(IConfiguration config)
    {
        _config = config;
    }

    public AuthResponse Generate(User user, List<string> roles, string? companyName = null, string? branchName = null)
    {
        var jwt = _config.GetSection("Jwt");

        // 1. Basic User Claims
        var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email!),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name, user.UserName!),
            new Claim("CompanyId", user.CompanyId?.ToString() ?? string.Empty),
            new Claim("BranchId", user.BranchId?.ToString() ?? string.Empty),
            new Claim("BranchName", branchName ?? string.Empty),
            new Claim("CompanyName", companyName ?? string.Empty),
            new Claim("SessionId", user.CurrentSessionId ?? string.Empty)
        };

        // ... (remaining roles and token creation logic stays the same)
        // 🛠️ PLATFORM ADMIN ROLE INJECTOR
        bool isPlatformAdmin = user.Email != null && user.Email.Equals("Default_Admin@gmail.com", StringComparison.OrdinalIgnoreCase);
        if (isPlatformAdmin && !roles.Contains("Super Admin", StringComparer.OrdinalIgnoreCase))
        {
            roles.Add("Super Admin");
        }

        foreach (var role in roles)
        {
            if (!string.IsNullOrEmpty(role))
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }
        }

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var expires = DateTime.UtcNow.AddMinutes(double.Parse(jwt["AccessTokenMinutes"]!));

        var token = new JwtSecurityToken(
            issuer: jwt["Issuer"],
            audience: jwt["Audience"],
            claims: claims,            
            expires: expires,
            signingCredentials: creds
        );

        var accessToken = new JwtSecurityTokenHandler().WriteToken(token);
        var refreshToken = Guid.NewGuid().ToString("N");

        return new AuthResponse
        {
            UserId = user.Id,
            AccessToken = accessToken,
            RefreshToken = refreshToken,
            ExpiresAt = expires,
            Roles = roles,
            Email = user.Email!,
            CompanyName = companyName,
            CompanyId = user.CompanyId,
            BranchId = user.BranchId,
            BranchName = branchName
        };
    }
}
