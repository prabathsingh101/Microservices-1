using MediatR;

public sealed record CreateProductCommand(
    Guid CategoryId,
    Guid SubcategoryId,    
    string ProductName,
    string Sku,
    string Brand,
    string Unit,
    string HsnCode,   
    decimal BasePurchasePrice,
    decimal Mrp,
    decimal Discount,
    decimal SaleRate,
    decimal DefaultGst,
    int MinStock,
    bool TrackInventory,
    bool IsActive,
    string? Description,
    string? CreatedBy,
    string ProductType,
    decimal DamagedStock,
    Guid? DefaultWarehouseId,
    Guid? DefaultRackId,
    bool IsExpiryRequired,
    string? ImageUrl,
    Guid CompanyId,
    string? BranchId = null
) : IRequest<Guid>;
