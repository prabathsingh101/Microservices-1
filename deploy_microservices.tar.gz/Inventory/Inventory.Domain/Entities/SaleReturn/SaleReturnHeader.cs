using Inventory.Domain.Common;
using Inventory.Domain.Entities.SO;
using System.ComponentModel.DataAnnotations;

namespace Inventory.Domain.Entities;

public class SaleReturnHeader : BaseAuditableEntity // Agar aap BaseAuditableEntity use kar rahe hain
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();

    [Required]
    [MaxLength(20)]
    public string ReturnNumber { get; set; } = string.Empty; // Example: SR-2026-0001

    public DateTime ReturnDate { get; set; } = DateTime.Now;

    [Required]
    public Guid SaleOrderId { get; set; }
    public virtual SaleOrder SaleOrder { get; set; } = null!;

    public Guid? CustomerId { get; set; } // Direct reference for easy reporting
    [System.ComponentModel.DataAnnotations.Schema.NotMapped]
    public string? GuestName { get; set; }
    [System.ComponentModel.DataAnnotations.Schema.NotMapped]
    public string? GuestPhone { get; set; }

    public decimal SubTotal { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal TotalAmount { get; set; }

    public decimal TotalReturnAmount { get; set; }
    public decimal TotalExchangeAmount { get; set; }
    public string ReturnMode { get; set; } = "RefundOnly";

    public string? Remarks { get; set; }
    public string Status { get; set; } = "Draft"; // Draft, Confirmed, Cancelled
    public string? GatePassNo { get; set; }
    public bool IsQuick { get; set; }

    public virtual ICollection<SaleReturnItem> ReturnItems { get; set; } = new List<SaleReturnItem>();
    public virtual ICollection<SaleExchangeItem> ExchangeItems { get; set; } = new List<SaleExchangeItem>();
}
