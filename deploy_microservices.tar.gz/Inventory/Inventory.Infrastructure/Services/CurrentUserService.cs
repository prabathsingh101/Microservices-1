using System.Security.Claims;
using Inventory.Application.Common.Interfaces;
using Microsoft.AspNetCore.Http;

namespace Inventory.Infrastructure.Services;

public class CurrentUserService : ICurrentUserService
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public CurrentUserService(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public Guid? CompanyId
    {
        get
        {
            var httpContext = _httpContextAccessor.HttpContext;
            if (httpContext == null) return null;

            // 1. Try X-Company-Id header first for company context switching
            var headerValue = httpContext.Request.Headers["X-Company-Id"].ToString();
            if (!string.IsNullOrEmpty(headerValue) && headerValue != "null")
            {
                if (Guid.TryParse(headerValue, out var headerId)) return headerId;
            }

            // 2. Fallback to JWT Claim
            var claims = httpContext.User?.Claims;
            if (claims != null)
            {
                var claimValue = claims.FirstOrDefault(c => 
                    c.Type.Equals("CompanyId", StringComparison.OrdinalIgnoreCase) || 
                    c.Type.Equals("companyid", StringComparison.OrdinalIgnoreCase))?.Value;

                if (Guid.TryParse(claimValue, out var companyId)) return companyId;
            }

            return null;
        }
    }

    public string? BranchId
    {
        get
        {
            var httpContext = _httpContextAccessor.HttpContext;
            if (httpContext == null) return null;

            var headerValue = httpContext.Request.Headers["X-Branch-Id"].ToString();
            if (!string.IsNullOrEmpty(headerValue) && headerValue != "null") return headerValue;

            var claims = httpContext.User?.Claims;
            if (claims != null)
            {
                var claimValue = claims.FirstOrDefault(c => 
                    c.Type.Equals("BranchId", StringComparison.OrdinalIgnoreCase) || 
                    c.Type.Equals("branchid", StringComparison.OrdinalIgnoreCase))?.Value;

                if (!string.IsNullOrEmpty(claimValue)) return claimValue;
            }

            return null;
        }
    }

    public string? Email
    {
        get
        {
            var claims = _httpContextAccessor.HttpContext?.User?.Claims;
            if (claims == null) return null;

            return claims.FirstOrDefault(c => 
                c.Type.Equals(ClaimTypes.Email, StringComparison.OrdinalIgnoreCase) || 
                c.Type.Equals("email", StringComparison.OrdinalIgnoreCase))?.Value;
        }
    }

    public bool IsSuperAdmin
    {
        get
        {
            var user = _httpContextAccessor.HttpContext?.User;
            if (user == null) return false;

            return user.IsInRole("Super Admin") || 
                   user.IsInRole("Default Admin") ||
                   user.Claims.Any(c => c.Type == ClaimTypes.Role && 
                       (c.Value.Equals("Super Admin", StringComparison.OrdinalIgnoreCase) || 
                        c.Value.Equals("Default Admin", StringComparison.OrdinalIgnoreCase)));
        }
    }

    public bool IsPlatformAdmin
    {
        get
        {
            var user = _httpContextAccessor.HttpContext?.User;
            if (user == null) return false;

            var email = user.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email || c.Type == "email")?.Value;
            var companyName = user.Claims.FirstOrDefault(c => c.Type == "CompanyName")?.Value;

            bool isPlatformEmail = email != null && email.Equals("Default_Admin@gmail.com", StringComparison.OrdinalIgnoreCase);
            bool isPlatformCompany = companyName != null && companyName.Equals("Admin Dashboard", StringComparison.OrdinalIgnoreCase);

            return isPlatformEmail || isPlatformCompany;
        }
    }
}
