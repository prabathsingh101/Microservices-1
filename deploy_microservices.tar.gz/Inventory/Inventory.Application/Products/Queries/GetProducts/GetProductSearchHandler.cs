using Inventory.Application.Common.Interfaces;
using Inventory.Application.Products.DTOs;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Inventory.Domain.Entities;

public class GetProductSearchHandler : IRequestHandler<GetProductSearchQuery, List<ProductSearchResponseDto>>
{
    private readonly IProductRepository _repository;
    private readonly IInventoryDbContext _context;

    public GetProductSearchHandler(IProductRepository repository, IInventoryDbContext context)
    {
        _repository = repository;
        _context = context;
    }

    public async Task<List<ProductSearchResponseDto>> Handle(GetProductSearchQuery request, CancellationToken cancellationToken)
    {
        // 1. Optimized Search using AsNoTracking to improve performance
        // Hum base query ko AsNoTracking ke saath handle kar rahe hain
        var products = await _context.Products
            .AsNoTracking()
            .Include(p => p.DefaultRack) // Include Rack for naming
            .Where(p => p.IsActive &&
                        (p.Name.Contains(request.Term) || p.Sku.Contains(request.Term) || (p.GenericName != null && p.GenericName.Contains(request.Term))))
            .ToListAsync(cancellationToken);

        var productDtos = new List<ProductSearchResponseDto>();

        foreach (var p in products)
        {
            productDtos.Add(new ProductSearchResponseDto
            {
                id = p.Id,
                name = p.Name,
                isActive = p.IsActive,
                basePurchasePrice = p.BasePurchasePrice,
                unit = p.Unit,
                brand = p.Brand,
                sku = p.Sku,
                hsncode = p.HSNCode,
                mrp = p.MRP,
                saleRate = p.SaleRate ?? 0,

                // GST and Discount directly from Product Master
                gstPercent = p.DefaultGst ?? 0,
                defaultGst = p.DefaultGst ?? 0,
                discount = p.Discount,
                discountPercent = p.DiscountPercent,

                // STEP 3: DIRECT BINDING WITH DATABASE COLUMN
                currentStock = (decimal)p.CurrentStock,
                defaultRackName = p.DefaultRack != null ? p.DefaultRack.Name : null,

                // 🆕 Expiry Requirement & Earliest Batch Dates
                isExpiryRequired = p.IsExpiryRequired,
                manufacturingDate = await _context.GRNDetails
                    .AsNoTracking()
                    .Where(g => g.ProductId == p.Id && (g.ReceivedQty - g.RejectedQty) > 0 && g.GRNHeader.Status != "Cancelled")
                    .OrderBy(g => g.ExpDate ?? DateTime.MaxValue)
                    .Select(g => g.MfgDate)
                    .FirstOrDefaultAsync(cancellationToken),
                expiryDate = await _context.GRNDetails
                    .AsNoTracking()
                    .Where(g => g.ProductId == p.Id && (g.ReceivedQty - g.RejectedQty) > 0 && g.GRNHeader.Status != "Cancelled")
                    .OrderBy(g => g.ExpDate ?? DateTime.MaxValue)
                    .Select(g => g.ExpDate)
                    .FirstOrDefaultAsync(cancellationToken),
                imageUrl = p.ImageUrl,
                genericName = p.GenericName,
                manufacturer = p.Manufacturer,
                scheduleClass = p.ScheduleClass
            });
        }

        return productDtos;
    }
}
