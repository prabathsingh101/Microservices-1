namespace Inventory.Application.DTOs.SaleOrder;

public class SaleOrderItemGridDto
{
    public Guid ProductId { get; set; }
    public string ProductName { get; set; } = string.Empty; // Table "Product" column
    public decimal SoldQty { get; set; } // Table "Sold Qty" column
    public decimal Rate { get; set; } // Table "Rate" column
    public decimal DiscountPercent { get; set; } // Table "Disc %" column
    public decimal DiscountAmount { get; set; } // Table "Disc (Amt)" column
    public decimal TaxPercentage { get; set; } // Table "Tax %" column
    public decimal GSTPercent { get; set; } // Map to gstPercent in frontend
    public decimal TaxAmount { get; set; } // Map to taxAmount in frontend
    public DateTime? MfgDate { get; set; }
    public DateTime? ExpDate { get; set; }
    public Guid? WarehouseId { get; set; }
    public string? WarehouseName { get; set; }
    public Guid? RackId { get; set; }
    public string? RackName { get; set; }
    public string? GrnNumber { get; set; }
    public string? RefNo { get; set; }
    public bool IsReturnable { get; set; }
    public double ReturnWindowRemainingHours { get; set; }
    public decimal CurrentStock { get; set; }
    public decimal Qty { get; set; }
    public string Unit { get; set; } = string.Empty;
    public decimal Total { get; set; }
}
