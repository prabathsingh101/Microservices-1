using Inventory.Application.Stock.Commands;
using Inventory.Application.Stock.Commands.RejectStock;
using Inventory.Application.Stock.Commands.MoveToExpiredRack;
using Inventory.Application.GRN.Command;
using Inventory.Application.Common.Interfaces;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.AspNetCore.SignalR;
using Inventory.API.Hubs;

namespace Inventory.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StockController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IStockRepository _stockRepo;
        private readonly IHubContext<DeliveryHub> _hubContext;

        public StockController(IMediator mediator, IStockRepository stockRepo, IHubContext<DeliveryHub> hubContext)
        {
            _mediator = mediator;
            _stockRepo = stockRepo;
            _hubContext = hubContext;
        }

        [HttpGet("current-stock")]
        [Authorize(Roles = "Admin, User, Manager, Employee, Warehouse, Super Admin, Salesman")]
        public async Task<IActionResult> GetStock(
           [FromQuery] string? search,
           [FromQuery] string? sortField,
           [FromQuery] string? sortOrder,
           [FromQuery] DateTime? startDate,
           [FromQuery] DateTime? endDate,
           [FromQuery] Guid? warehouseId,
           [FromQuery] Guid? rackId,
           [FromQuery] bool showPurged = false,
           [FromQuery] int pageIndex = 0,
           [FromQuery] int pageSize = 10,
           [FromQuery] string? branchId = null)
        {
            var command = new GetCurrentStockCommand(search, sortField, sortOrder, pageIndex, pageSize, startDate, endDate, warehouseId, rackId, showPurged, branchId);
            var result = await _mediator.Send(command);
            return Ok(result);
        }

        [HttpPost("ExportExcel")]
        [Authorize(Roles = "Admin, User, Manager, Employee, Warehouse, Super Admin, Salesman")]
        public async Task<IActionResult> ExportExcel([FromBody] List<Guid> productIds)
        {
            if (productIds == null || !productIds.Any())
                return BadRequest("No products selected.");

            try
            {
                var fileContent = await _stockRepo.GenerateStockExcel(productIds);
                var indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"));
                string fileName = $"StockReport_{indianTime:yyyyMMdd_HHmm}.xlsx";

                return File(
                    fileContent,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    fileName
                );
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("adjust")]
        [Authorize(Roles = "Admin, User, Manager, Employee, Warehouse, Super Admin, Salesman")]
        public async Task<IActionResult> AdjustStock([FromBody] RejectStockCommand command)
        {
            var result = await _mediator.Send(command);
            if (result)
            {
                if (!string.IsNullOrEmpty(command.BranchId))
                {
                    await _hubContext.Clients.Group(command.BranchId).SendAsync("ReceiveInventoryUpdate");
                }
                else
                {
                    await _hubContext.Clients.All.SendAsync("ReceiveInventoryUpdate");
                }
            }
            return Ok(new { success = result, message = result ? "Stock adjusted successfully" : "Failed to adjust stock. Item not found or insufficient quantity." });
        }

        [HttpPost("move-to-expired")]
        [Authorize(Roles = "Admin, User, Manager, Employee, Warehouse, Super Admin, Salesman")]
        public async Task<IActionResult> MoveToExpired([FromBody] MoveToExpiredRackCommand command)
        {
            try
            {
                var result = await _mediator.Send(command);
                if (result)
                {
                    await _hubContext.Clients.All.SendAsync("ReceiveInventoryUpdate");
                }
                return Ok(new { success = result, message = "Batch moved to Expired Rack successfully." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }


        [HttpGet("batch-history")]
        [Authorize(Roles = "Admin, User, Manager, Employee, Warehouse, Super Admin, Salesman")]
        public async Task<IActionResult> GetBatchHistory(
            [FromQuery] Guid productId,
            [FromQuery] Guid warehouseId,
            [FromQuery] Guid rackId,
            [FromQuery] DateTime? mfgDate,
            [FromQuery] DateTime? expDate,
            [FromQuery] string? branchId = null)
        {
            var result = await _stockRepo.GetBatchTransactionsAsync(productId, warehouseId, rackId, mfgDate, expDate, branchId);
            return Ok(result);
        }

        [HttpPost("sync")]
        [Authorize(Roles = "Admin, User, Manager, Employee, Warehouse, Super Admin, Salesman")]
        public async Task<IActionResult> Sync()
        {
            var result = await _mediator.Send(new SyncStockCommand());
            if (result)
            {
                await _hubContext.Clients.All.SendAsync("ReceiveInventoryUpdate");
            }
            return Ok(new { success = result, message = "Stock synchronized successfully." });
        }

        [HttpGet("warehouse-stock")]
        [Authorize(Roles = "Admin, User, Manager, Employee, Warehouse, Super Admin, Salesman")]
        public async Task<IActionResult> GetWarehouseStock(
           [FromQuery] string? search,
           [FromQuery] string? sortField,
           [FromQuery] string? sortOrder,
           [FromQuery] int pageIndex = 0,
           [FromQuery] int pageSize = 10,
           [FromQuery] Guid? productId = null,
           [FromQuery] Guid? warehouseId = null,
           [FromQuery] string? branchId = null)
        {
            var result = await _stockRepo.GetWarehouseStockAsync(search, sortField, sortOrder, pageIndex, pageSize, productId, warehouseId, branchId);
            return Ok(result);
        }

        [HttpGet("disposed-stock")]
        [Authorize(Roles = "Admin, User, Manager, Employee, Warehouse, Super Admin, Salesman")]
        public async Task<IActionResult> GetDisposedStock(
           [FromQuery] string? search,
           [FromQuery] string? sortField,
           [FromQuery] string? sortOrder,
           [FromQuery] DateTime? startDate,
           [FromQuery] DateTime? endDate,
           [FromQuery] Guid? warehouseId,
           [FromQuery] Guid? rackId,
           [FromQuery] int pageIndex = 0,
           [FromQuery] int pageSize = 10,
           [FromQuery] string? branchId = null)
        {
            var result = await _stockRepo.GetDisposedStockAsync(search, sortField, sortOrder, pageIndex, pageSize, startDate, endDate, warehouseId, rackId, branchId);
            return Ok(result);
        }
    }
}
